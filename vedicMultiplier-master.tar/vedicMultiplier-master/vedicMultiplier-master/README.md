Vedic Multiplier with flopped inputs and outputs 
This project implements a hardware design of a high speed Multiplier using techniques of Vedic Mathematics that improves the overall performance of any arithmetic unit. 
iverilog -v test.v adder*.v halfAdder.v  vedic_*.v
